
function changeColor() {
    let a='0123456789abcdef';
let b='#';

for(let i=0;i<6;i++){
    b+=a[Math.floor(Math.random()*16)];
}
return b;
}


document.getElementById('green').addEventListener('click', function(){
    document.body.style.backgroundColor="green"
});

document.getElementById('red').addEventListener('click',function(){
    document.body.style.backgroundColor="red";
});

document.getElementById('blue').addEventListener('click',function(){
    document.body.style.backgroundColor="blue";
});

document.getElementById('yellow').addEventListener('click',function(){

    document.body.style.backgroundColor=changeColor();
});


